#include <stdio.h>

int main()
{

    int x;
    
    x=0;

    while (x < 10) {
        printf("%d\n", x);
        x++;
    }
    getchar();
}
