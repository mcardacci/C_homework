#include <stdarg.h>
#include <stdio.h>

/* This function will take the number of values 
   followed by all of the numbers to average */

double average(int num, ...)
{
    va_list arguments;
    double sum = 0;
}
