# include <stdio.h>

int main()
{
    printf("I'm alive! Beware.\n" );
    getchar();
    return 0;
}
