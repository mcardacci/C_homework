#include <stdio.h>

int main()
{
    int x;

    x=0;
    do {
        printf("Hello, world!\n");
        x++;
    } while (x != 10);
    getchar();
}
